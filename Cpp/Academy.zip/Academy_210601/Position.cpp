#include "Position.h"


Position::Position() {
}

Position::Position(int xAxis, int yAxis)
{
	x = xAxis;
	y = yAxis;
}