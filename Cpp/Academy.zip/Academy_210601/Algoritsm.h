#pragma once
#define N 4
class Algoritsm
{
public:
	int FindXPosition(int puzzle[N][N]);
	int GetInvCount(int arr[]);
	bool IsSolvable(int puzzle[N][N]);
};

